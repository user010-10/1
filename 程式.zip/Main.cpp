﻿#include "Library.h"
#include <iostream>
#include <string>

using namespace std;

int main() {
    Library library;

    // 添加書籍到圖書館
    library.addBook("物件導向程式設計", "作者A", true);
    library.addBook("白雪公主", "作者B", false);
    library.addBook("哈利波特", "作者C", true);

    string searchTitle;
    cout << "請輸入要查詢的書籍名稱: ";
    getline(cin, searchTitle);

    if (cin.fail() || searchTitle.empty()) {
        cerr << "輸入錯誤。書名不可為空，請重新輸入。"<<endl;
        return 1;
    }

    library.displayLibraryInfo(); 
    library.searchBook(searchTitle);

    return 0;
}
