#ifndef LIBRARY_H
#define LIBRARY_H

#include "LibrarySystem.h"
#include <vector>
#include "Book.h"

// �~�� LibrarySystem
class Library : public LibrarySystem {
private:
    vector<Book> books; // �s�x���y�C��
public:
    void addBook(string title, string author, bool available) override;
    void searchBook(string title) override;
    void displayBookInfo(Book& book) const; // ��ܮ��y��T
    void displayLibraryInfo() const override; // ��ܹϮ��]��T
};

#endif
