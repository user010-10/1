﻿#include "Library.h"
#include <iostream>
#include <iomanip>

// 新增書籍
void Library::addBook(string title, string author, bool available) {
    books.push_back(Book(title, author, available));
}

// 查詢書籍
void Library::searchBook(string title) {
    for (Book& book : books) {
        if (book.getTitle() == title) {
            displayBookInfo(book); 
            return;
        }
    }
    cout << "很抱歉，該書籍不在圖書館中。"<<endl;
}

// 顯示書籍資訊
void Library::displayBookInfo(Book& book) const {
    cout << "=== [書籍資訊] ===" << endl;
    cout << "書名：" << book.getTitle() << endl;
    cout << "作者：" << book.getAuthor() << endl;
    cout << "狀態：" << (book.isAvailableToBorrow() ? "可借閱" : "已被借閱") << endl;
}

// 顯示圖書館資訊
void Library::displayLibraryInfo() const {
    cout << "=== [圖書館書籍查詢系統] ==="<<endl;
}