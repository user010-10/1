#ifndef BOOK_H
#define BOOK_H

#include <string>
#include <iostream>
using namespace std;

class Book {
private:
    string title;
    string author;
    bool isAvailable;
public:
    Book(string, string, bool);
    string getTitle() const;
    string getAuthor() const;
    bool isAvailableToBorrow() const;
};

#endif
